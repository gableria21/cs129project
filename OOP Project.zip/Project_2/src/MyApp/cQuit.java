/**
 * Programmers:     LERIA, Gian Andrei
 * 		    LIZANO, Danette Julianne
 * 		    LORENZO, Anna Georgina
 *		    MANGALI, Carlo
 * 		    UY, Mary Claire
 *.  		    CS129-8 /OL160
 */
package MyApp;

import javax.swing.JFrame;
import javax.swing.JOptionPane;


class cQuit {
    
    private JFrame frame;
    
    public void quit(){
        frame = new JFrame("Exit");
        if (JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit", "Travel Pass Record System",
                JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION){
            System.exit(0);
        }
    }
    
}
