/**
 * Programmers:     LERIA, Gian Andrei
 * 		    LIZANO, Danette Julianne
 * 		    LORENZO, Anna Georgina
 *		    MANGALI, Carlo
 * 		    UY, Mary Claire
 *.  		    CS129-8 /OL160
 */


package MyLib;

public interface PersonInterface {
    
    String getFirstName();
    void setFirstName(String firstName);
    
    String getMiddleName();
    void setMiddleName(String middleName);
    
    String getLastName();
    void setLastName(String lastName);

    String getFullName();
    
}
