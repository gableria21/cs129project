/**
 * Programmers:     LERIA, Gian Andrei
 * 		    LIZANO, Danette Julianne
 * 		    LORENZO, Anna Georgina
 *		    MANGALI, Carlo
 * 		    UY, Mary Claire
 *.  		    CS129-8 /OL160
 */

package MyLib;

import java.sql.*;
import java.util.*;

public class ApplicantDAO {
    
    private static final String TABLE_NAME = "tbl_applicant";
    
    private static final String INSERT_APPLICANT = "INSERT INTO " + TABLE_NAME +  " (first_name, middle_name, last_name, birthdate, province, city, barangay, street_address, email, cellphone_number, landline, reasons_for_travel, point_of_origin, point_of_destination, status, applicant_id_number, date_added) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String LIST = "SELECT * FROM " + TABLE_NAME;
    
    public static List<Applicant> getRegularTraveller() throws ClassNotFoundException, SQLException {
        
        List<Applicant> list = new ArrayList<>();
        
        try(Connection connection = JDBCUtils.getConnection();
                PreparedStatement ps = connection.prepareStatement("SELECT * FROM tbl_applicant WHERE status = 0")) {
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()) {
                
                String firstName = rs.getString("first_name");
                String middleName = rs.getString("middle_name");
                String lastName = rs.getString("last_name");
                String birthDate = rs.getString("birthdate");
                String province = rs.getString("province");
                String city = rs.getString("city");
                String barangay = rs.getString("barangay");
                String streetAddress = rs.getString("street_address");
                String email = rs.getString("email");
                String cellphone = rs.getString("cellphone_number");
                String landline = rs.getString("landline");
               
                int reasonsForTravel = rs.getInt("reasons_for_travel");
                int pointOfOrigin = rs.getInt("point_of_origin");
                int pointOfDestination = rs.getInt("point_of_destination");
                int status = rs.getInt("status");
                String applicantIDNumber = rs.getString("applicant_id_number");
                String dateAdded = rs.getString("date_added");

                Applicant applicant = new Applicant(firstName, middleName, lastName, birthDate, province, city, barangay, streetAddress, email, cellphone,
                landline, reasonsForTravel, pointOfOrigin, pointOfDestination, status, applicantIDNumber, dateAdded);
                
                list.add(applicant);
                
            }
            
        }
        
        return list;
        
    }
    
    public static List<Applicant> getLSI() throws ClassNotFoundException, SQLException {
        
        List<Applicant> list = new ArrayList<>();
        
        try(Connection connection = JDBCUtils.getConnection();
                PreparedStatement ps = connection.prepareStatement("SELECT * FROM tbl_applicant WHERE status = 1")) {
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()) {
                
                String firstName = rs.getString("first_name");
                String middleName = rs.getString("middle_name");
                String lastName = rs.getString("last_name");
                String birthDate = rs.getString("birthdate");
                String province = rs.getString("province");
                String city = rs.getString("city");
                String barangay = rs.getString("barangay");
                String streetAddress = rs.getString("street_address");
                String email = rs.getString("email");
                String cellphone = rs.getString("cellphone_number");
                String landline = rs.getString("landline");
               
                int reasonsForTravel = rs.getInt("reasons_for_travel");
                int pointOfOrigin = rs.getInt("point_of_origin");
                int pointOfDestination = rs.getInt("point_of_destination");
                int status = rs.getInt("status");
                String applicantIDNumber = rs.getString("applicant_id_number");
                String dateAdded = rs.getString("date_added");

                Applicant applicant = new Applicant(firstName, middleName, lastName, birthDate, province, city, barangay, streetAddress, email, cellphone,
                landline, reasonsForTravel, pointOfOrigin, pointOfDestination, status, applicantIDNumber, dateAdded);
                
                list.add(applicant);
                
            }
            
        }
        
        return list;
        
    }
    
    public static List<Applicant> getList() throws ClassNotFoundException, SQLException {
        
        List<Applicant> list = new ArrayList<>();
        
        try(Connection connection = JDBCUtils.getConnection();
                PreparedStatement ps = connection.prepareStatement(LIST)) {
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()) {
                
                String firstName = rs.getString("first_name");
                String middleName = rs.getString("middle_name");
                String lastName = rs.getString("last_name");
                String birthDate = rs.getString("birthdate");
                String province = rs.getString("province");
                String city = rs.getString("city");
                String barangay = rs.getString("barangay");
                String streetAddress = rs.getString("street_address");
                String email = rs.getString("email");
                String cellphone = rs.getString("cellphone_number");
                String landline = rs.getString("landline");
               
                int reasonsForTravel = rs.getInt("reasons_for_travel");
                int pointOfOrigin = rs.getInt("point_of_origin");
                int pointOfDestination = rs.getInt("point_of_destination");
                int status = rs.getInt("status");
                String applicantIDNumber = rs.getString("applicant_id_number");
                String dateAdded = rs.getString("date_added");

                Applicant applicant = new Applicant(firstName, middleName, lastName, birthDate, province, city, barangay, streetAddress, email, cellphone,
                landline, reasonsForTravel, pointOfOrigin, pointOfDestination, status, applicantIDNumber, dateAdded);
                
                list.add(applicant);
                
            }
            
        }
        
        return list;
        
    }
    
    public static Applicant viewApplicant(String applicantIDNumber) throws ClassNotFoundException, SQLException {
        
        try(Connection connection = JDBCUtils.getConnection();
                PreparedStatement ps = connection.prepareStatement("SELECT * FROM tbl_applicant WHERE applicant_id_number = ?")) {
            // Personal information
            ps.setString(1, applicantIDNumber);
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()) {
                
                String firstName = rs.getString("first_name");
                String middleName = rs.getString("middle_name");
                String lastName = rs.getString("last_name");
                String birthDate = rs.getString("birthdate");
                String province = rs.getString("province");
                String city = rs.getString("city");
                String barangay = rs.getString("barangay");
                String streetAddress = rs.getString("street_address");
                String email = rs.getString("email");
                String cellphone = rs.getString("cellphone_number");
                String landline = rs.getString("landline");
               
                int reasonsForTravel = rs.getInt("reasons_for_travel");
                int pointOfOrigin = rs.getInt("point_of_origin");
                int pointOfDestination = rs.getInt("point_of_destination");
                int status = rs.getInt("status");
                String ID = rs.getString("applicant_id_number");
                String dateAdded = rs.getString("date_added");

                return new Applicant(firstName, middleName, lastName, birthDate, province, city, barangay, streetAddress, email, cellphone,
                landline, reasonsForTravel, pointOfOrigin, pointOfDestination, status, applicantIDNumber, dateAdded);
            }
            
        }
        
        return null;
        
    }
    
    public static int insertApplicant(Applicant applicant) throws ClassNotFoundException, SQLException {
        
        try(Connection connection = JDBCUtils.getConnection();
                PreparedStatement ps = connection.prepareStatement(INSERT_APPLICANT)) {
            // Personal information
            ps.setString(1, applicant.getFirstName());
            ps.setString(2, applicant.getMiddleName());
            ps.setString(3, applicant.getLastName());
            ps.setString(4, applicant.getBirthDate());
            ps.setString(5, applicant.getProvince());
            ps.setString(6, applicant.getCity());
            ps.setString(7, applicant.getBarangay());
            ps.setString(8, applicant.getStreetAddress());
            ps.setString(9, applicant.getEmail());
            ps.setString(10, applicant.getCellphone());
            ps.setString(11, applicant.getLandline());
            // Travel Information
            ps.setInt(12, applicant.getReasonsForTravel());
            ps.setInt(13, applicant.getPointOfOrigin());
            ps.setInt(14, applicant.getPointOfDestination());
            ps.setInt(15, applicant.getStatus());
            ps.setString(16, applicant.getApplicantIDNumber());
            ps.setString(17, applicant.getDateAdded());
            
            return ps.executeUpdate();
            
        }
        
    }
    
}
