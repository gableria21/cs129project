/**
 * Programmers:     LERIA, Gian Andrei
 * 		    LIZANO, Danette Julianne
 * 		    LORENZO, Anna Georgina
 *		    MANGALI, Carlo
 * 		    UY, Mary Claire
 *.  		    CS129-8 /OL160
 */



package MyLib;

import java.text.*;
import java.time.*;
import java.util.*;


public class Option {
    
    private static String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    
    private static int[] days = new int[31];
    
    private static String[] years = new String[100];
    
    private static String[] reasonsForTravel = 
    {
        "Leaving province to attend family / medical emergency", 
        "Leaving NCR to attend family / medical emergency",
        "Locally stranded individual going to province",
        "Locally stranded individual going to NCR",
    };
    
    private static String[] statuses = {
        
      "Regular Travller",
      "LSI"
        
    };
    
    private static String[] regions = {
        
        "NCR – National Capital Region",
        "Region I – Ilocos Region", 
        "Region II – Cagayan Valley", 
        "Region III – Central Luzon", 
        "Region IV‑A – CALABARZON", 
        "Region V – Bicol Region", 
        "Region VI – Western Visayas", 
        "Region VII – Central Visayas", 
        "Region VIII – Eastern Visayas", 
        "Region IX – Zamboanga Peninsula", 
        "Region X – Northern Mindanao", 
        "Region XI – Davao Region", 
        "Region XII – SOCCSKSARGEN", 
        "Region XIII – Caraga", 
        "Region X – Northern Mindanao", 
        "Region XI – Davao Region", 
        "Region XII – SOCCSKSARGEN", 
        "CAR – Cordillera Administrative Region",
        "ARMM – Autonomous Region in Muslim Mindanao"

    };
    
    public static String[] getMonths() {
        
        return months;
        
    }
    
    public static String getMonth(int i) {
        
        return months[i];
        
    }
    
    public static int[] getDays() {  
        
        for(int j = 1; j < 31; j++) {
            
            days[j-1] = j;
            
        }
        
        return days;
        
    }
    
    public static int getDay(int i) {

        for(int j = 1; j < 31; j++) {
            
            days[j-1] = j;
            
        }
        
        return days[i];
        
    }
    
    public static String[] getYears() {                         

        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("Y");
        int year = Integer.parseInt(formatter.format(date));
        
        int diff = (year - 10) - 1945;
        
        years = new String[diff];
        
        int count = 0;
        
        for(int j = 1945; j < year - 10; j++) {
            
            years[count] = Integer.toString(j);
            count++;
        }
        
        return years;
        
    }
    
    public static String getYear(int i) {

        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("Y");
        int year = Integer.parseInt(formatter.format(date));
        
        int diff = (year - 10) - 1945;
        
        years = new String[diff];
        
        int count = 0;
        
        for(int j = 1945; j < year - 10; j++) {
            
            years[count] = Integer.toString(j);
            count++;
        }
        
        return years[i];
        
    }

    public static String[] getRegions() {
        
        return regions;
        
    }
    
    public static String getRegion(int i) {
        
        return regions[i];
        
    }
    
    public static String[] getReasonsForTravel() {
        
        return reasonsForTravel;
        
    }
    
    public static String getReasonForTravel(int i) {
        
        return reasonsForTravel[i];
        
    }
    
    public static String[] getStatuses() {
        
        return statuses;
        
    }
    
    public static String getStatus(int i) {
        
        return statuses[i];
        
    }

}
