/**
 * Programmers:     LERIA, Gian Andrei
 * 		    LIZANO, Danette Julianne
 * 		    LORENZO, Anna Georgina
 *		    MANGALI, Carlo
 * 		    UY, Mary Claire
 *.  		    CS129-8 /OL160
 */


package MyLib;

public class Applicant extends Person {
	
    //Personal Information
    
    private int id;

    private String dateAdded;
    
    //Travel Information

    private int reasonsForTravel;
    private int pointOfOrigin;
    private int pointOfDestination;

    private int status;

    public Applicant() {
        
        

    }

    public Applicant(String firstName, String middleName, String lastName, String birthDate, String province, String city, String barangay, String streetAddress,
        String email, String cellphone, String landline, int reasonForTravel, int pointOfOrigin, int pointOfDestination, int status, String applicantIDNumber, String dateAdded) {

        this.setFirstName(firstName);
        this.setMiddleName(middleName);
        this.setLastName(lastName);
        this.setBirthDate(birthDate);
        this.setProvince(province);
        this.setCity(city);
        this.setBarangay(barangay);
        this.setStreetAddress(streetAddress);
        this.setEmail(email);
        this.setCellphone(cellphone);
        this.setLandline(landline);
        this.setReasonsForTravel(reasonsForTravel);
        this.setPointOfOrigin(pointOfOrigin);
        this.setPointOfDestination(pointOfDestination);
        this.setStatus(status);
        this.setApplicantIDNumber(applicantIDNumber);
        this.setDateAdded(dateAdded);

    }
    
    public int getId() {
        
        return id;
        
    }

    public void setId(int id) {
        
        this.id = id;
        
    }
    
        public int getReasonsForTravel() {

        return reasonsForTravel;

    }

    public void setReasonsForTravel(int reasonsForTravel) {

        this.reasonsForTravel = reasonsForTravel;

    }
    
    public int getPointOfOrigin() {

        return pointOfOrigin;

    }

    public void setPointOfOrigin(int pointOfOrigin) {

        this.pointOfOrigin = pointOfOrigin;

    }
    
    public int getPointOfDestination() {

        return pointOfDestination;

    }

    public void setPointOfDestination(int pointOfDestination) {

       this.pointOfDestination = pointOfDestination;

    }
        
    
     public int getStatus() {

        return status;

    }

    public void setStatus(int status) {

        this.status = status;

    }
    
    public String getDateAdded() {

        return dateAdded;

    }

    public void setDateAdded(String dateAdded) {

        this.dateAdded = dateAdded;

    }

    @Override
    public String getFirstName() {
        
        return firstName;
   
    }

    @Override
    public void setFirstName(String firstName) {
        
        this.firstName = firstName;
    }

    @Override
    public String getMiddleName() {
        
       return middleName;
    
    }

    @Override
    public void setMiddleName(String middleName) {
        
        this.middleName = middleName;
   
    }

    @Override
    public String getLastName() {
        
       return lastName;
  
    }

    @Override
    public void setLastName(String lastName) {
        
       this.lastName = lastName;
   
    }

    @Override
    public String getFullName() {
        
        return getFirstName() + " " + getMiddleName() + " " + getLastName();
        
    }
    
}