/**
 * Programmers:     LERIA, Gian Andrei
 * 		    LIZANO, Danette Julianne
 * 		    LORENZO, Anna Georgina
 *		    MANGALI, Carlo
 * 		    UY, Mary Claire
 *.  		    CS129-8 /OL160
 */

package MyLib;

import java.sql.*;

public class JDBCUtils {
    
    public static Connection getConnection() {
        
        try {
        
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost/project","root","");
        
        } catch(ClassNotFoundException ex) {
            
            return null;

        } catch(SQLException ex) {
            
            return null;
            
        }
        
    }
    
}
